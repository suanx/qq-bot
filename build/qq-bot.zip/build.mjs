/**
 * 构建脚本（零依赖）
 *  1. 校验部署所需目录结构
 *  2. 跑一遍自测作为构建门禁
 *  3. 打包为可直接上传 EdgeOne 的 zip 产物
 * 用法： npm run build
 */
import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';
import { execFileSync } from 'node:child_process';

const ROOT = resolve('.');
const OUT_DIR = join(ROOT, 'build');
const ZIP_PATH = join(OUT_DIR, 'qq-bot.zip');

/** 部署必需文件（缺失会导致线上不可用） */
const REQUIRED = [
  'package.json',
  'dev-server.mjs',
  'admin/index.html',
  'functions/api/qq/webhook.js',
  'functions/api/qq/health.js',
  'functions/api/admin/login.js',
  'functions/api/admin/logout.js',
  'functions/api/admin/me.js',
  'functions/api/admin/overview.js',
  'functions/api/admin/groups.js',
  'functions/api/admin/members.js',
  'functions/api/admin/violations.js',
  'functions/api/admin/rules.js',
  'functions/api/admin/admins.js',
  'functions/api/admin/logs.js',
  'src/core.js',
  'src/handlers.js',
  'src/verify.js',
  'src/config.js',
  'src/adfilter.js',
  'src/moderation.js',
  'src/qqapi.js',
  'src/ai.js',
  'src/kv.js',
  'src/repo.js',
  'src/records.js',
  'src/store.js',
  'src/admin/auth.js',
  'src/admin/api.js',
  'src/admin/crud.js',
];

/** 不打进产物：机密 / 本地调试 / 测试脚手架 */
const EXCLUDE_DIRS = new Set(['build', '.git', 'node_modules', '.workbuddy', 'probe', 'test']);
const EXCLUDE_FILES = new Set(['.env', '.env.local', '.DS_Store']);

function bail(msg) {
  console.error('\n构建失败: ' + msg);
  process.exit(1);
}

console.log('=== 1. 校验部署结构 ===');
for (const p of REQUIRED) {
  const ok = existsSync(join(ROOT, p));
  console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + p);
  if (!ok) bail('缺少 ' + p);
}

console.log('\n=== 2. 运行自测（构建门禁）===');
try {
  const out = execFileSync(process.execPath, [join(ROOT, 'test', 'selftest.mjs')], { encoding: 'utf8' });
  const line = out.split('\n').filter((l) => l.includes('自测结果')).pop() || '(未解析)';
  console.log('  ' + line.trim());
  if (/([1-9]\d*) 失败/.test(line)) bail('存在失败用例');
} catch (e) {
  bail('自测未通过: ' + (e.message || e));
}

console.log('\n=== 3. 打包产物 ===');
mkdirSync(OUT_DIR, { recursive: true });

function collect(dir, acc = []) {
  for (const name of readdirSync(dir)) {
    if (EXCLUDE_DIRS.has(name)) continue;
    const abs = join(dir, name);
    let st;
    try { st = statSync(abs); } catch { continue; }
    if (st.isDirectory()) { collect(abs, acc); continue; }
    if (EXCLUDE_FILES.has(name)) continue;
    acc.push(relative(ROOT, abs).split(sep).join('/'));
  }
  return acc;
}

const names = collect(ROOT).sort();

/* ---- 极简 ZIP 写入（STORE，无压缩，零依赖） ---- */
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

const chunks = [];
const central = [];
let offset = 0;

for (const name of names) {
  const data = readFileSync(join(ROOT, name));
  const crc = crc32(data);
  const nameBuf = Buffer.from(name, 'utf8');

  const lfh = Buffer.alloc(30);
  lfh.writeUInt32LE(0x04034b50, 0);
  lfh.writeUInt16LE(20, 4);      // version needed
  lfh.writeUInt16LE(0, 6);        // flags
  lfh.writeUInt16LE(0, 8);        // method: store
  lfh.writeUInt16LE(0, 10);       // mod time
  lfh.writeUInt16LE(0x21, 12);   // mod date (1980-01-01)
  lfh.writeUInt32LE(crc, 14);
  lfh.writeUInt32LE(data.length, 18);
  lfh.writeUInt32LE(data.length, 22);
  lfh.writeUInt16LE(nameBuf.length, 26);
  lfh.writeUInt16LE(0, 28);
  chunks.push(lfh, nameBuf, data);

  const cdh = Buffer.alloc(46);
  cdh.writeUInt32LE(0x02014b50, 0);
  cdh.writeUInt16LE(20, 4);       // version made by
  cdh.writeUInt16LE(20, 6);        // version needed
  cdh.writeUInt16LE(0, 8);         // flags
  cdh.writeUInt16LE(0, 10);        // method
  cdh.writeUInt16LE(0, 12);        // time
  cdh.writeUInt16LE(0x21, 14);     // date
  cdh.writeUInt32LE(crc, 16);
  cdh.writeUInt32LE(data.length, 20);
  cdh.writeUInt32LE(data.length, 24);
  cdh.writeUInt16LE(nameBuf.length, 28);
  cdh.writeUInt16LE(0, 30);       // extra
  cdh.writeUInt16LE(0, 32);       // comment
  cdh.writeUInt16LE(0, 34);        // disk
  cdh.writeUInt16LE(0, 36);        // internal attrs
  cdh.writeUInt32LE(0, 38);        // external attrs
  cdh.writeUInt32LE(offset, 42);
  central.push(cdh, nameBuf);

  offset += lfh.length + nameBuf.length + data.length;
}

const cdSize = central.reduce((n, b) => n + b.length, 0);
const eocd = Buffer.alloc(22);
eocd.writeUInt32LE(0x06054b50, 0);
eocd.writeUInt16LE(0, 4);
eocd.writeUInt16LE(0, 6);
eocd.writeUInt16LE(names.length, 8);
eocd.writeUInt16LE(names.length, 10);
eocd.writeUInt32LE(cdSize, 12);
eocd.writeUInt32LE(offset, 16);
eocd.writeUInt16LE(0, 20);

writeFileSync(ZIP_PATH, Buffer.concat([...chunks, ...central, eocd]));

const bytes = statSync(ZIP_PATH).size;
console.log('  产物: ' + relative(ROOT, ZIP_PATH));
console.log('  文件数: ' + names.length);
console.log('  大小: ' + (bytes / 1024).toFixed(1) + ' KB');
console.log('\n构建完成 ✅');
